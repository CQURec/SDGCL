import sys,os
sys.path.append(os.getcwd())
import torch as th
import numpy as np
from torch_scatter import scatter_mean
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
import copy




class GCN_textGAP(th.nn.Module):
    def __init__(self,args):
        super(GCN_textGAP, self).__init__()
        self.conv1 = GCNConv(5000, args.hidden_features)
        self.conv2 = GCNConv(args.hidden_features*2 , args.output_features)
        self.fc = th.nn.Linear(5000, args.hidden_features)
        self.device = args.device

    def forward(self, data):
        x, edge_index = data.x[:, :5000], data.edge_index
        x_1=self.fc(x)
        rootindex = data.rootindex
        root_extend = th.zeros(len(data.batch), x_1.size(1)).to(self.device)
        batch_size = max(data.batch) + 1
        for num_batch in range(batch_size):
            index = (th.eq(data.batch, num_batch))
            first_true_index = th.nonzero(index).squeeze()[0]
            index[first_true_index]=False
            root_extend[index] = x_1[rootindex[num_batch]]
        x_diff = x_1-root_extend
        x = self.conv1(x, edge_index)
        x = th.cat((x,x_diff),1)
        x = F.relu(x)
        x = F.dropout(x, training=self.training)
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        x= scatter_mean(x, data.batch, dim=0)

        return x



class TDrumorGCN(th.nn.Module):
    def __init__(self,args):
        super(TDrumorGCN, self).__init__()
        self.conv1 = GCNConv(5000, args.hidden_features)
        self.conv2 = GCNConv(5000 + args.hidden_features , args.output_features)
        self.device = args.device

    def forward(self, data):
        x, edge_index = data.x[:, :5000], data.edge_index
        x1=copy.copy(x.float())
        x = self.conv1(x, edge_index)
        x2=copy.copy(x)
        rootindex = data.rootindex
        root_extend = th.zeros(len(data.batch), x1.size(1)).to(self.device)
        batch_size = max(data.batch) + 1
        for num_batch in range(batch_size):
            index = (th.eq(data.batch, num_batch))
            root_extend[index] = x1[rootindex[num_batch]]
        x = th.cat((x,root_extend), 1)

        x = F.relu(x)
        x = F.dropout(x, training=self.training)
        x = self.conv2(x, edge_index)
        x = F.relu(x)
        root_extend = th.zeros(len(data.batch), x2.size(1)).to(self.device)
        for num_batch in range(batch_size):
            index = (th.eq(data.batch, num_batch))
            root_extend[index] = x2[rootindex[num_batch]]
        x = th.cat((x, root_extend), 1)
        x= scatter_mean(x, data.batch, dim=0)

        return x





class BiGCN(th.nn.Module):
    def __init__(self, args):
        super(BiGCN, self).__init__()
        self.gcn_textGAP = GCN_textGAP(args)
        self.TDrumorGCN = TDrumorGCN(args)
        self.alignfc_g = th.nn.Linear(args.hidden_features, args.hidden_features)
        self.alignfc_t = th.nn.Linear(args.hidden_features + args.output_features, args.hidden_features)
        self.fc = th.nn.Linear(args.output_features+args.hidden_features + args.output_features, args.num_class)

    def forward(self, data):
        gap_x = self.gcn_textGAP(data)
        TD_x = self.TDrumorGCN(data)
        align_g = self.alignfc_g(gap_x)
        align_t = self.alignfc_t(TD_x)
        dist = [align_g, align_t]
        x = th.cat((gap_x, TD_x), 1)
        x = self.fc(x)
        x = F.log_softmax(x, dim=1)
        return x,dist


