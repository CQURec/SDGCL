import logging
import os
import time
import colorlog

# 这里是为了永远将日志文件夹放在当前工程目录下，而不至于当项目下有多个子目录时,每个子目录下都分别有各自的日志（会很混乱）
def projectpath():
    pwd = os.getcwd()
    while(len(pwd.split('/'))>5):#这个数字看情况设置
        pwd = os.path.dirname(pwd) # 向上退一级目录
    # print(pwd)
    return pwd

def __logfun(isfile=False,name=''):
    # black, red, green, yellow, blue, purple, cyan(青) and white, bold(亮白色)
    log_colors_config = {
        'DEBUG': 'bold_white',
        'INFO': 'bold',
        'WARNING': 'blue',
        'ERROR': 'red',
        'CRITICAL': 'bold_red', # 加bold后色彩变亮
    }
    logger = logging.getLogger()
    logger.handlers.clear()
    # 输出到console
    # logger.setLevel(level=logging.DEBUG)
    logger.setLevel(level=logging.DEBUG) # 某些python库文件中有一些DEBUG级的输出信息，如果这里设置为DEBUG，会导致console和log文件中写入海量信息
    #logger 对象负责将日志消息分发到不同的 handler，而 handler 对象负责将日志消息输出到不同的目标，logger相当于总开关。高于logger的等级会发送到handler，高于handler的等级才有可能被输出
    console_formatter = colorlog.ColoredFormatter(
        # fmt='%(log_color)s[%(asctime)s.%(msecs)03d] %(filename)s -> %(funcName)s liloggne:%(lineno)d [%(levelname)s] : %(message)s',
        fmt='%(log_color)s %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s',
        # datefmt='%Y-%m-%d  %H:%M:%S',
        log_colors=log_colors_config
    )
    console = logging.StreamHandler()  # 输出到console的handler
    # console.setLevel(logging.DEBUG)
    console.setLevel(logging.INFO)#控制台的输出级别
    console.setFormatter(console_formatter)
    logger.addHandler(console)
    # 输出到文件
    if isfile:
        # 设置文件名
        time_line = time.strftime('%Y%m%d%H%M', time.localtime(time.time()))
        log_path=os.path.join(projectpath(),'log')
        if not os.path.exists(log_path):
            os.mkdir(log_path)
        logfile = log_path + '/'+time_line + name+'.txt'
        # 设置文件日志格式
        filer = logging.FileHandler(logfile,mode='w') # 输出到log文件的handler
        filer.setLevel(level=logging.WARNING)
        file_formatter = logging.Formatter(
            fmt='%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s',
            datefmt='%Y-%m-%d  %H:%M:%S'
        )
        # formatter = logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")
        filer.setFormatter(file_formatter)
        logger.addHandler(filer)

    return logger
log=__logfun(isfile=True)  #True表示要存，False表示不用存
if __name__=='__main__':
    log.debug('This is a debug message.')
    log.info('This is an info message.')
    log.warning('This is a warning message.')
    log.error('This is an error message.')
    log.critical('This is a critical message.')
