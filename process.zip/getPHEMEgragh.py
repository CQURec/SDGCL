# -*- coding: utf-8 -*-
import os
import numpy as np
from joblib import Parallel, delayed
from tqdm import tqdm
import sys
cwd=os.getcwd()
T_num = 6
vec_dimension=5021

class Node_tweet(object):
    def __init__(self, idx=None):
        self.children = []
        self.idx = idx
        self.wordVec=[]
        self.parent = None
        self.timespan=None

def str2matrix(Str):  # str = index:wordfreq index:wordfreq
    vec= []
    for item in Str.split(' '):
        vec.append(float(item))
    return vec
def timeSegment(tree):
    t_list = []
    for i in tree:
        t = tree[i]['timespan']
        t_list.append(t)
    max_t = max(t_list)
    sliding_T = float(max_t) / T_num

    return sliding_T
def constructMat(tree):
    sliding_t=timeSegment(tree)
    index2node = {}
    for i in tree:
        node = Node_tweet(idx=i)
        index2node[i] = node
    for j in tree:
        indexC = j
        indexP = tree[j]['parent']
        nodeC = index2node[indexC]
        nodeC.wordVec=str2matrix(tree[j]['vec'])
        nodeC.timespan=tree[j]['timespan']

        ## not root node ##
        if not indexP == 'None':
            nodeP = index2node[int(indexP)]
            nodeC.parent = nodeP
            nodeP.children.append(nodeC)
        ## root node ##
        else:
            rootindex=indexC
    rootfeat = index2node[rootindex].wordVec
    matrix=np.zeros([len(index2node),len(index2node)])#邻接矩阵？但是好像邻接矩阵没有返回说明没用上
    row=[]
    col=[]
    x_x=[]
    x_seq_inx=[]
    edge_seq_inx=[]
    # for index_i in range(len(index2node)):
    #     for index_j in range(len(index2node)):
    #         if index2node[index_i+1].children != None and index2node[index_j+1] in index2node[index_i+1].children:
    #             matrix[index_i][index_j]=1
    #             row.append(index_i)
    #             col.append(index_j)
    #             for k in range(t_num):
    #                 if k * sliding_t < float(index2node[index_j + 1].timespan) and float(index2node[index_j + 1].timespan) <= (k + 1) * sliding_t:
    #                     edge_seq_inx.append(k + 1)
    #     x_x.append(index2node[index_i+1].wordVec)
    #     for k in range(t_num):
    #         if k * sliding_t < float(index2node[index_i + 1].timespan) and float(index2node[index_i + 1].timespan) <= (k + 1) * sliding_t:
    #             x_seq_inx.append(k+1)
    for index_i in range(len(index2node)):
        for index_j in range(len(index2node)):
            if index2node[index_i+1].children != None and index2node[index_j+1] == index2node[index_i+1].parent:
                matrix[index_i][index_j]=1
                row.append(index_j)
                col.append(index_i)
                for k in range(T_num):
                    if k * sliding_t < float(index2node[index_i + 1].timespan) and float(index2node[index_i + 1].timespan) <= (k + 1) * sliding_t:
                        edge_seq_inx.append(k + 1)
        x_x.append(index2node[index_i+1].wordVec) #这里节点1是放在了从0开始的数组里面所以根节点的下标应该是0
        for k in range(T_num):
            if k * sliding_t < float(index2node[index_i + 1].timespan) and float(index2node[index_i + 1].timespan) <= (k + 1) * sliding_t:
                x_seq_inx.append(k+1)
    edgematrix=[row,col]
    return x_x, edgematrix,rootfeat,rootindex,x_seq_inx,edge_seq_inx

def getfeature(x_word,x_index):
    x = np.zeros([len(x_index), 5019])
    for i in range(len(x_index)):
        if len(x_index[i])>0:
            x[i, np.array(x_index[i])] = np.array(x_word[i])
    return x

def subGraphAll(x_seq_inx, edge_seq_inx,x_x, edge_index):#x_seq_inx是指这个节点是在哪个时间窗口，但是不包含根节点
    x_x=x_x.T
    all_graph_x=np.empty((5019,0))
    all_graph_edge=np.empty((2,0),dtype=np.int64)
    inx=0
    #将根节点作为子图0
    all_graph_x = np.concatenate((all_graph_x, x_x[:, :inx + 1]), axis=1)
    all_graph_inx = np.zeros(1,dtype=int)
    edge_index = edge_index + inx + 1  # 每拼接一个图增值，第0个图是根节点一个节点所以加1
    #根据x_seq_inx, edge_seq_inx拼接子图
    for num in range(1,T_num+1):#比如有7个子图那肯定1-7个子图都要加上了（主要是在设置x_seq_inx, edge_seq_inx的时候是从1开始的）
        pos_list=[i for i,x in enumerate(x_seq_inx) if x==num]#因为他们的seq_index是一样的才能这样，不然edge的要重新获取
        if pos_list:
            inx = pos_list.pop() +1#如果该时间段有新增的节点和边就新增，不然就用上一次的（相当于不新增节点，还是上个时间的子图）#因为切片操作不会取最后一位，比如子图1有4个节点对应的x_seq_inx是0-3这里就等于3下面要截取前4个就要加1
        all_graph_x=np.concatenate((all_graph_x,x_x[:, :inx+1]),axis=1) #因为有根节点seq_index没有算根节点，于是要继续后移一位（#因为x_seq_inx没有存根节点的划分，但坐标是0开始所以+1移到正确的位置）
        all_graph_edge=np.concatenate((all_graph_edge,edge_index[:, :inx]),axis=1)
        edge_index = edge_index + inx+1#每拼接一个图增值增值，这个也是对应x的增加所以同理要+1
        # 创建全是1的1维数组并将数组中的每个元素设置为num
        graph_num = np.ones(inx + 1,dtype=int)*num#+1是因为和x是对应的，同理是因为根节点
        all_graph_inx = np.concatenate((all_graph_inx,graph_num))

    return all_graph_edge,all_graph_x.T,all_graph_inx#它们的生成格式都是严格按照torch_geometric.data.Data的要求不然torch_geometric.data.Dataloader时会导致维度不一致的问题


def main():
    # 事件id-标签
    label_path=os.path.join( '../data/' + 'Pheme' + '/label.npy')
    label_dic = np.load(label_path, allow_pickle=True).item()

    treePath = os.path.join( '../data/' + 'Pheme' + '/PHEME_TD.vol_5000_metafeatures_2h.txt')
    print("reading PHEME tree")
    treeDic = {}
    event=[]#记录新闻（源tweet）id
    for line in open(treePath):
        line = line.rstrip()
        eid, indexP, indexC = line.split('\t')[0], line.split('\t')[1], int(line.split('\t')[2])
        timespan,Vec = line.split('\t')[3], line.split('\t')[4]
        if not treeDic.__contains__(eid):
            treeDic[eid] = {}
            event.append(eid)
        treeDic[eid][indexC] = {'parent': indexP, 'timespan': timespan, 'vec': Vec}
    print('tree no:', len(treeDic))
    print("loading dataset", )
    Parallel(n_jobs=30, backend='threading')(delayed(loadEid)(treeDic[eid] if eid in treeDic else None,eid,label_dic[eid]) for eid in tqdm(event))
    return

def loadEid(event,id,y):
    if event is None: #这里event是一个新闻所有post数组
        return None
    if len(event) < 2:
        return None
    if len(event)>1:
        x_x, edge_index, rootfeat, rootindex, x_seq_inx, edge_seq_inx = constructMat(event)
        rootfeat, edge_index, x_x, rootindex, y, x_seq_inx, edge_seq_inx = np.array(rootfeat), np.array(edge_index), np.array(x_x), np.array(
            rootindex), np.array(y), np.array(x_seq_inx), np.array(edge_seq_inx)
        all_graph_edge, all_graph_x, all_graph_inx = subGraphAll(x_seq_inx, edge_seq_inx, x_x, edge_index)
        np.savez( os.path.join('../data/'+'Pheme/'+'graph_{}/'.format(T_num)+id+'.npz'), x=x_x,root=rootfeat,edgeindex=edge_index,rootindex=rootindex,
                  y=y,x_seq_inx=x_seq_inx,edge_seq_inx=edge_seq_inx,all_graph_edge=all_graph_edge, all_graph_x=all_graph_x,
                  all_graph_inx=all_graph_inx, graph_num=T_num)
        return None




if __name__ == '__main__':
    main()