import os
import numpy as np
import torch
import random
from torch.utils.data import Dataset
from torch_geometric.data import Data
# import networkx as nx
import matplotlib.pyplot as plt

class GraphDataset(Dataset):
    def __init__(self, fold_x, treeDic,lower=20, upper=100000, droprate=0,
                 data_path=os.path.join('..','..', 'data', 'Weibograph')):
        self.fold_x = list(filter(lambda id: id in treeDic and len(treeDic[id]) >= lower and len(treeDic[id]) <= upper, fold_x))
        self.treeDic = treeDic
        self.data_path = data_path
        self.droprate = droprate

    def __len__(self):
        return len(self.fold_x)

    def __getitem__(self, index):
        id =self.fold_x[index]
        data=np.load(os.path.join(self.data_path, id + ".npz"), allow_pickle=True)
        edgeindex = data['all_graph_edge']
        if self.droprate > 0:
            row = list(edgeindex[0])
            col = list(edgeindex[1])
            length = len(row)
            poslist = random.sample(range(length), int(length * (1 - self.droprate)))
            poslist = sorted(poslist)
            row = list(np.array(row)[poslist])
            col = list(np.array(col)[poslist])
            new_edgeindex = [row, col]
        else:
            new_edgeindex = edgeindex
        return Data(x=torch.tensor(data['all_graph_x'],dtype=torch.float32),
                    edge_index=torch.LongTensor(new_edgeindex),
             y=torch.LongTensor([int(data['y'])]),
             rootindex=torch.LongTensor([int(data['rootindex'])]),mini=torch.tensor(data['all_graph_inx']))
        # edge_list = [(new_edgeindex[0, i].item(), new_edgeindex[1, i].item())
        #              for i in range(new_edgeindex.shape[1])]
        #
        # G = nx.Graph(edge_list)
        # connected_subgraphs = list(nx.connected_components(G))
        # subgraph = G.subgraph(connected_subgraphs[-1])
        # nx.draw(subgraph,with_labels=True,node_size=55, node_color='blue', edge_color='black', width=2)
        # plt.show()
        # batch = torch.tensor([0, 0, 1, 1], dtype=torch.long)
        # return Data(x=torch.tensor(data['all_graph_x'],dtype=torch.float32),
        #             edge_index=torch.LongTensor(new_edgeindex),
        #      y=torch.LongTensor([int(data['y'])]),
        #      rootindex=torch.LongTensor([int(data['rootindex'])]))


def collate_fn(data):
    return data



