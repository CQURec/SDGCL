# -*- coding: utf-8 -*-
import os
import numpy as np
from joblib import Parallel, delayed
from tqdm import tqdm
import sys
cwd=os.getcwd()

def main():
    # 事件id-标签
    label_path=os.path.join( '../data/' + 'Pheme' + '/PHEME_label_yuanlaide.npy')
    label_dic = np.load(label_path, allow_pickle=True).item()

    treePath = os.path.join( '../data/' + 'Pheme' + '/PHEME_TD.vol_5000.txt')
    print("reading PHEME tree")
    treeDic = {}
    event=[]#这里event记录每条新闻的id
    for line in open(treePath):
        line = line.rstrip()
        eid, indexP, indexC = line.split('\t')[0], line.split('\t')[1], int(line.split('\t')[2])
        timespan,Vec = line.split('\t')[3], line.split('\t')[4]
        if not treeDic.__contains__(eid):
            treeDic[eid] = {}
            event.append(eid)
        treeDic[eid][indexC] = {'parent': indexP, 'timespan': timespan, 'vec': Vec}
    print('tree no:', len(treeDic))
    print("loading label", )
    Parallel(n_jobs=30, backend='threading')(delayed(loadEid)(treeDic[eid] if eid in treeDic else None,eid,label_dic[eid]) for eid in tqdm(event)) #就是一个for循环
    return

def loadEid(event,id,y):
    if event is None: #这里event是一个新闻所有post数组
        return None
    if len(event) < 2:
        return None
    if len(event)>1:
        save_f=os.path.join('../data/'+'Pheme/'+'PHEME_label'+'.txt')
        with open(save_f, 'a', encoding='utf8') as f:#每次运行之前要删除原来的不然就是在后面添加，但是如果用'w'又每次会被覆盖掉除非写在循环外面但是这个循环实在main里面
            f.write(str(id) + '\t' + str(y))
            f.write('\n')
        return None
if __name__ == '__main__':
    main()